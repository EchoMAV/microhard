import asyncio
from pysnmp.hlapi.asyncio import *

# SNMPv3 User Credentials
auth_data = UsmUserData(
    'username',                   # Replace with your SNMPv3 username
    authKey='authpassword',       # Replace with your authentication password
    privKey='privpassword',       # Replace with your privacy password
    authProtocol=usmHMACSHAAuthProtocol,  # Use appropriate protocol (SHA shown here)
    privProtocol=usmAesCfb128Protocol     # Use appropriate protocol (AES shown here)
)

# Callback for processing received traps
async def trap_receiver(snmp_engine, state_reference, context_engine_id, context_name, var_binds, cb_ctx):
    print("Received SNMPv3 Trap:")
    for name, value in var_binds:
        print(f'{name.prettyPrint()} = {value.prettyPrint()}')  # Displays raw OID and value

# Main async function to set up the SNMP listener
async def main():
    snmp_engine = SnmpEngine()

    # Setup the UDP listener with .create()
    udp_transport = await UdpTransport().create(('0.0.0.0', 162))  # Bind to port 162

    # Register the listener
    snmp_engine.transportDispatcher.registerTransport(
        udp_transport.domainName,
        udp_transport
    )

    # Register trap receiver callback
    snmp_engine.transportDispatcher.registerRecvCbFun(trap_receiver)

    print("Listening for SNMPv3 traps on UDP port 162...")
    await snmp_engine.transportDispatcher.jobStarted(1)  # Start the dispatcher
    try:
        # Run the asyncio loop
        await asyncio.get_event_loop().run_forever()
    finally:
        snmp_engine.transportDispatcher.closeDispatcher()

# Run the main event loop
asyncio.run(main())
